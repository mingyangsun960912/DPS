# Implementing Laplace mechanism on Adult dataset
import pandas as pd
import numpy as np
import csv
import copy
import random

def output_synthetic_data(out_fname, histogram):
	with open(out_fname, 'w') as output_file:
		fieldnames = ['Age', 'Gender', 'Race', 'Count']
		writer = csv.DictWriter(output_file, fieldnames = fieldnames)

		writer.writeheader()

		for i in range(0, len(histogram)):
			for j in range(0, len(histogram[i])):
				for k in range(0, len(histogram[i][j])):
					count = histogram[i][j][k]
					writer.writerow({'Age': str(i + 17), 'Race': str(j + 1), 'Gender': str(k + 1), 'Count': str(count)})

def construct_original_histogram():
	# Load dataset
	dataset = pd.read_csv("adult_age_gender_race_dataset.csv",
	    names=["Age", "Gender", "Race"])

	age = []
	race = []
	gender = []

	# Find actual data count
	age_stats = dataset["Age"].value_counts()
	race_stats = dataset["Race"].value_counts()
	gender_stats = dataset["Gender"].value_counts()

	age_span = 90 - 17 + 1
	race_span = 5
	gender_span = 2
	# Construct real histogram
	orig_hist = np.zeros((age_span, race_span, gender_span))

	with open('adult_age_gender_race_dataset.csv') as csvfile:
		reader = csv.DictReader(csvfile)
		for row in reader:
			orig_hist[int(row['Age']) - 17][int(row['Race']) - 1][int(row['Gender']) - 1] += 1

	return orig_hist



def construct_private_histogram(scale, orig_hist):
	age_span = 90 - 17 + 1
	race_span = 5
	gender_span = 2

	# Set parameters for Laplace function 
	location = 0.0

	laplace_noise = np.random.laplace(location, 1.0 / scale, age_span * race_span * gender_span)
	permutated_hist = copy.deepcopy(orig_hist)

	index = 0;
	for i in range(0, len(orig_hist)):
		for j in range(0, len(orig_hist[i])):
			for k in range(0, len(orig_hist[i][j])):
				permutated_hist[i][j][k] += laplace_noise[index]
				# smooth the bin
				if permutated_hist[i][j][k] < 0:
					permutated_hist[i][j][k] = 0
				index += 1

	return permutated_hist

def perform_query(age_min, age_max, race_list, gender_list, private_hist, orig_hist):
	# age race gender
	orig_count = 0
	for i in range(0, len(orig_hist)):
		age = i + 17
		if age >= age_min and age <= age_max:
			for j in range(0, len(orig_hist[i])):
				# race
				if j + 1 in race_list:
					for k in range(0, len(orig_hist[i][j])):
						if k + 1 in gender_list:
							orig_count += orig_hist[i][j][k]
				else :
					continue
		else:
			continue
	perm_count = 0
	for i in range(0, len(orig_hist)):
		age = i + 17
		if age >= age_min and age <= age_max:
			for j in range(0, len(orig_hist[i])):
				# race
				if j + 1 in race_list:
					for k in range(0, len(orig_hist[i][j])):
						if k + 1 in gender_list:
							perm_count += private_hist[i][j][k]
				else :
					continue
		else:
			continue
	return (orig_count, perm_count)




if __name__ == '__main__':
	orig_hist = construct_original_histogram()
	private_histogram = construct_private_histogram(0.2, orig_hist)
	output_synthetic_data('output.csv', private_histogram)

	# perform
	cum_error = 0
	for i in range(0, 1000):
		# generate random age
		age_min = random.randint(17, 90)
		age_max = age_min + random.randint(0, 73)
		race_list = []
		for j in range(0, random.randint(1, 5)):
			race_list.append(random.randint(1, 5))
		gender_list = []
		for k in range(0, random.randint(1, 2)):
			gender_list.append(random.randint(1, 2))
		result = perform_query(age_min, age_max, race_list, gender_list, private_histogram, orig_hist)
		if (result[0] == 0):
			continue
		relative_error = float(result[1] - result[0]) / float(result[0])
		cum_error += relative_error
	print(cum_error / 1000)

	private_histogram = construct_private_histogram(0.5, orig_hist)
	output_synthetic_data('output.csv', private_histogram)


