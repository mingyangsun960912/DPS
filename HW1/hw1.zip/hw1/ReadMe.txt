The program is written in python and runs one pass to generate permitted histogram, synthetic dataset and average relative error of random queries performed on both datasets.
All the parameters are in the main function.

Run this program with:

python laplaceDP.py