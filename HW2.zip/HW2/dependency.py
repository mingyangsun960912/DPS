import keras
import numpy as np
import tensorflow as tf
from keras import backend as K
from tensorflow.python.platform import flags
flags = tf.app.flags 
FLAGS = flags.FLAGS

slim = tf.contrib.slim