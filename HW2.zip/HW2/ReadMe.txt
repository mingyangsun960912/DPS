Required files:
dependency,py
tiny_imagenet_loader.py
three ckpt files 

Environment:
python 3.6

Running command:
python3 FGSM path-to-images eps

Note:
1. The default setting is 1000 images from tiny-image-net-200
2. Please run with GPU support, otherwise the process gets killed because of low swap issue.
