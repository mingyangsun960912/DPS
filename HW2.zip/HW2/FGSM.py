import tensorflow as tf
import numpy as np
from resnet_model import Model
import tiny_imagenet_loader as tl
from sklearn.metrics import accuracy_score
import sys


def fgsm(x, eps, logits, y):
	"""
	FGSM method

	model: model used to classify data
	x: data to be perturbed, input tenser
	eps: noise strength

	return: output tenser, contains adversarial samples
	"""

	x_bar = x
	
	loss_fn = tf.nn.sigmoid_cross_entropy_with_logits
	noise_fn = tf.sign 

	y_tensor = tf.convert_to_tensor(y, dtype=tf.float32)

	loss = loss_fn(labels = y_tensor, logits = logits)

	gradient, = tf.gradients(ys=loss, xs=x_bar)
	
	noise = noise_fn(gradient)

	x_bar = tf.stop_gradient(x_bar + eps * noise)

	return x_bar


def load_image_data(image_data_path):
	
	# load training data
	loader = tl.TinyImageNetLoader('train', image_data_path)
	return loader.load_n_images_all_classes(nb = 5)

def create_model(x, y, y_encoded, eps):
	graph = tf.Graph()
	with graph.as_default():
		images = tf.placeholder(tf.float32, (None, 64, 64, 3))
		labels = tf.placeholder(tf.float32, (None, 200))
		# preprocessing
		_R_MEAN = 123.68
		_G_MEAN = 116.78
		_B_MEAN = 103.94
		_CHANNEL_MEANS = [_R_MEAN, _G_MEAN, _B_MEAN]
		features = images - tf.constant(_CHANNEL_MEANS)
		with tf.variable_scope('target') as scope:
			model = Model(
				resnet_size=18,
				bottleneck=False,
				num_classes=200,
				num_filters=64,
				kernel_size=3,
				conv_stride=1,
				first_pool_size=0,
				first_pool_stride=2,
				second_pool_size=7,
				second_pool_stride=1,
				block_sizes=[2, 2, 2, 2],
				block_strides=[1, 2, 2, 2],
				final_size=512,
				version=2,
				data_format=None)

			logits = model(features, False)

		with tf.Session() as sess:
			sess.run(tf.global_variables_initializer())
			# Load target classifier
		
			saver = tf.train.Saver(var_list=tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='target'))
			saver.restore(sess, 'model.ckpt-5865')

			prediction = tf.argmax(logits, 1)

			ypred = prediction.eval(feed_dict = {images: x})

			# perturb
			xbar = fgsm(images, eps, logits, y_encoded)
			print(images)
			res = xbar.eval(feed_dict = {images: x, labels: y_encoded})

			ypred_bar = prediction.eval(feed_dict = {images: res})

			acc_before = accuracy_score(y, ypred)
			acc_after = accuracy_score(y, ypred_bar)
			print("Accuracy rate before attack: %.5f" %(acc_before))
			print("Value of epsilon: %.8f" %(eps))
			print("Accuracy rate after attack: %.5f" %(acc_after))
			print("Accuracy rate drops %.5f" %(acc_before - acc_after))

   

	return graph, saver, images, logits

def convert_one_hot_encode(labels_encoded):
	labels = []
	for i in range(0, len(labels_encoded)):
		for k in range(0, 200):
			if labels_encoded[i][k] == 1:
				labels.append(k)
				break
	return labels

def run_resnet_model(data_path, eps):
	image_data = load_image_data(data_path)
	features = image_data[0]
	labels_encoded = image_data[1]
	labels = np.asarray(convert_one_hot_encode(labels_encoded))

	create_model(features, labels, labels_encoded, float(eps))

if __name__ == "__main__":
	# data path
	data_path = sys.argv[1]
	# eps
	eps = sys.argv[2]
	run_resnet_model(data_path, eps)



