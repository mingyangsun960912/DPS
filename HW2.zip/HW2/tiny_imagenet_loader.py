"""
This file is provided by Yonghui Xiao (yhandxiao@gmail.com), and only used for Dr. Xiong(lxiong@emory.edu)'s CS 573 class.
You have to contact Dr. Xiong or Yonghui if you want use it for other purpose.
"""
import glob
import re
import os
import numpy as np
from PIL import Image


class TinyImageNetLoader(object):
    """Loader for images from the the Tiny ImageNet set for images of a specific class."""
    def __init__(self, mode, data_path, data_type='float32'):
        # mode = 'train' or 'val';
        # data_path: the relative path of tiniy-imagenet, '../tiny-imagenet-200',
        self.data_path = data_path
        self.data_type = data_type
        with open(self.path('wnids.txt')) as f: # detail info of image
            wnids = f.readlines()
            assert len(wnids) == 200
            wnids = [x.strip() for x in wnids]
            self.wnids = wnids
            self.mode = mode
        images = {}
        if mode == 'val': # load validation set
            with open(self.path('val/val_annotations.txt')) as f:
                labels = f.readlines()
                #assert len(labels) == 10000
                labels = [x.split('\t')[:2] for x in labels]
                for image, wnid in labels:
                    #assert wnid in self.wnids
                    #assert image.endswith('.JPEG')
                    images.setdefault(wnid, []).append(data_path + '/val/images/' + image)

                #assert len(images) == len(wnids)
                #for wnid in images:
                #    assert len(images[wnid]) == 50
        if mode == 'train': # load training set
            filenames = glob.glob(data_path + '/train/*/images/*.JPEG')
            for filename in filenames:
                wnid = re.search(r'n\d+', filename)
                #label = str(label_dict[match.group()])
                #filenames_labels.append((filename, label))
                images.setdefault(wnid.group(), []).append(filename)
        self.imagefiles_wnid_dict = images
        # print(len(self.imagefiles_wnid_dict))
            

    def path(self, *path):
        return os.path.join(self.data_path, *path)

    def load_image(self, filename):
        path = os.path.join(filename)
        image = Image.open(path)
        image = np.asarray(image)
        if image.shape != (64, 64, 3):
            # e.g. grayscale
            return None
        assert image.dtype == np.uint8
        image = image.astype(self.data_type)
        assert image.shape == (64, 64, 3)
        return image

    def load_n_images_all_classes(self, nb=10):
        # nb: number of samples per class, for validation data, max =50, for train, max=500
        # return: X_data in [n, 64, 64, 3], Y_data in [n, 1]
        X_data=np.ndarray([nb*200,64,64,3], dtype=self.data_type)
        Y_data=np.zeros([nb*200,200], dtype=self.data_type)# one hot encoded
        arr = np.arange(nb*200)
        np.random.shuffle(arr) # shuffle images
        
        for label in range(200):
            wnid = self.wnids[label]
            files = self.imagefiles_wnid_dict[wnid]
            for i, filename in enumerate(files):
                if i==nb:
                    break
                #print(i,filename)
                raw_image = self.load_image(filename)
                #raw_image = raw_image.astype(np.float32)
                #print(label*nb+i)
                X_data[arr[label*nb+i],:,:,:] = raw_image
                Y_data[arr[label*nb+i],label] = 1
                #print(label)
        return X_data, Y_data
